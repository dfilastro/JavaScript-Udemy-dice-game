'use strict';

// Selecting elements
const score0El = document.querySelector('#score--0');
const score1El = document.getElementById('score--1');
const diceEl = document.querySelector('.dice');
const current0El = document.querySelector('#current--0');
const current1El = document.querySelector('#current--1');
const btnNew = document.querySelector('.btn--new');
const btnRoll = document.querySelector('.btn--roll');
const btnHold = document.querySelector('.btn--hold');
const active0 = document.querySelector('.player--0');
const active1 = document.querySelector('.player--1');

// Starting conditions
score0El.textContent = 0;
score1El.textContent = 0;
diceEl.classList.add('hidden');

let currentScore = 0;
let activePlayer = 0;
let sumScore0 = 0;
let sumScore1 = 0;
const maxScore = 100;

// Rolling dice funcionality
btnRoll.addEventListener('click', function () {
  // 1.Generate a random number
  if (sumScore0 < maxScore && sumScore1 < maxScore) {
    const dice = Math.trunc(Math.random() * 6 + 1);

    // 2. Display dice
    diceEl.classList.remove('hidden');
    diceEl.src = `dice-${dice}.png`;

    // 3. Check for rolled 1: if true, switch to the next player
    if (dice !== 1) {
      // Add the dice to the current score
      currentScore += dice;
      document.getElementById(`current--${activePlayer}`).textContent =
        currentScore;
    } else {
      // Switch to the next player
      document.getElementById(`current--${activePlayer}`).textContent =
        currentScore = 0;
      activePlayer = activePlayer === 1 ? 0 : 1;

      // Change background collor of active player
      if (activePlayer === 1) {
        active0.classList.remove('player--active');
        active1.classList.add('player--active');
      } else {
        active1.classList.remove('player--active');
        active0.classList.add('player--active');
      }
    }
  }
});

// Hold button funcionality
btnHold.addEventListener('click', function () {
  if (sumScore0 < maxScore && sumScore1 < maxScore) {
    // check if there is a winner
    if (activePlayer === 0) {
      sumScore0 += currentScore;
      score0El.textContent = sumScore0;

      // check if the winner is player 1
      if (sumScore0 < maxScore) {
        active0.classList.remove('player--active');
        active1.classList.add('player--active');
        document.getElementById(`current--${activePlayer}`).textContent =
          currentScore = 0;
        activePlayer = activePlayer === 1 ? 0 : 1;
      } else {
        active0.classList.add('player--winner');
        diceEl.classList.add('hidden');
      }
    } else if (activePlayer === 1) {
      sumScore1 += currentScore;
      score1El.textContent = sumScore1;

      // check if the winner is player 2
      if (sumScore1 < maxScore) {
        active1.classList.remove('player--active');
        active0.classList.add('player--active');
        document.getElementById(`current--${activePlayer}`).textContent =
          currentScore = 0;
        activePlayer = activePlayer === 1 ? 0 : 1;
      } else {
        active1.classList.add('player--winner');
        diceEl.classList.add('hidden');
      }
    }
  }
});

// New Game button funcionality
btnNew.addEventListener('click', function () {
  score0El.textContent = 0;
  score1El.textContent = 0;
  diceEl.classList.add('hidden');

  active1.classList.remove('player--active');
  active0.classList.add('player--active');
  active0.classList.remove('player--winner');
  active1.classList.remove('player--winner');
  document.getElementById(`current--${activePlayer}`).textContent =
    currentScore = 0;

  currentScore = 0;
  activePlayer = 0;
  sumScore0 = 0;
  sumScore1 = 0;
});
